package package_tienda.ventas;

public class EncFactura {
}
