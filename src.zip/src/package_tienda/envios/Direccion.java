package package_tienda.envios;

public class Direccion {
}
