package package_tienda.productos;

public class Categoria {
}
