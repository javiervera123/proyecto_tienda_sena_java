package package_tienda.mi_libreria;

public abstract class Factura {
    protected  int id;
    protected String nombre;

}
