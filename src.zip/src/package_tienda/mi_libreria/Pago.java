package package_tienda.mi_libreria;

public abstract class Pago {
    protected int id;
    protected String nombre;
    protected String apellido1;
}
