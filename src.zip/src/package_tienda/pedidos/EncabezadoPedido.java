package package_tienda.pedidos;

public class EncabezadoPedido {
}
